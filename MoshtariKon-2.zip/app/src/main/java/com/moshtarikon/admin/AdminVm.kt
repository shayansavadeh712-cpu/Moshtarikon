package com.moshtarikon.admin

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import org.json.JSONObject

class AdminVm(app: Application) : AndroidViewModel(app) {
    private val sp = app.getSharedPreferences("admin", 0)

    var token by mutableStateOf(Vault.dec(sp.getString("tk", "") ?: ""))
        private set
    var lastUser by mutableStateOf(sp.getString("user", "") ?: "")
    val loggedIn: Boolean get() = token.isNotEmpty()

    var tab by mutableIntStateOf(0)
    var busy by mutableStateOf(false)
    var msg by mutableStateOf<String?>(null)

    var stats by mutableStateOf<JSONObject?>(null)

    val customers = mutableStateListOf<JSONObject>()
    var custTotal by mutableIntStateOf(0)
    var custPage by mutableIntStateOf(0)
    var custQuery by mutableStateOf("")
    var custFilter by mutableStateOf("")
    var detail by mutableStateOf<JSONObject?>(null)

    val plans = mutableStateListOf<JSONObject>()
    val payments = mutableStateListOf<JSONObject>()
    var payFilter by mutableStateOf("")
    var payPage by mutableIntStateOf(0)
    var payMore by mutableStateOf(false)
    val coupons = mutableStateListOf<JSONObject>()

    private fun req(
        method: String,
        path: String,
        query: Map<String, String> = emptyMap(),
        body: JSONObject? = null,
        done: (JSONObject) -> Unit = {}
    ) {
        viewModelScope.launch {
            busy = true
            try {
                val r = Api.call(method, path, token, body, query)
                if (r.code == 401 && path != "/admin/login") {
                    logout()
                    msg = "نشست تمام شد؛ دوباره وارد شو"
                } else if (r.ok) {
                    done(r.json!!)
                } else {
                    msg = r.err()
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                msg = "اتصال به سرور برقرار نشد"
            }
            busy = false
        }
    }

    fun login(user: String, pass: String) {
        req("POST", "/admin/login", body = JSONObject().put("username", user.trim()).put("password", pass)) { j ->
            token = j.optString("token")
            lastUser = user.trim()
            sp.edit().putString("tk", Vault.enc(token)).putString("user", lastUser).apply()
            tab = 0
            loadStats()
        }
    }

    fun logout() {
        token = ""
        sp.edit().remove("tk").apply()
        stats = null
        customers.clear()
        plans.clear()
        payments.clear()
        coupons.clear()
        detail = null
    }

    fun loadStats() = req("GET", "/admin/stats") { stats = it }

    // ── مشتری‌ها
    fun loadCustomers(reset: Boolean) {
        val page = if (reset) 1 else custPage + 1
        req("GET", "/admin/customers", mapOf("q" to custQuery, "filter" to custFilter, "page" to page.toString())) { j ->
            if (reset) customers.clear()
            val a = j.optJSONArray("items")
            if (a != null) for (i in 0 until a.length()) customers.add(a.getJSONObject(i))
            custTotal = j.optInt("total")
            custPage = page
        }
    }

    val custHasMore: Boolean get() = customers.size < custTotal

    fun openCustomer(id: Long) = req("GET", "/admin/customer", mapOf("id" to id.toString())) { detail = it }

    private fun reopen(id: Long) {
        openCustomer(id)
        loadCustomers(true)
    }

    fun grant(id: Long, days: Int, note: String?) {
        val b = JSONObject().put("id", id).put("days", days)
        if (note != null) b.put("note", note)
        req("POST", "/admin/grant", body = b) { msg = "انجام شد"; reopen(id) }
    }

    fun saveNote(id: Long, note: String) {
        req("POST", "/admin/grant", body = JSONObject().put("id", id).put("days", 0).put("note", note)) {
            msg = "یادداشت ذخیره شد"
            reopen(id)
        }
    }

    fun ban(id: Long, banned: Boolean) =
        req("POST", "/admin/ban", body = JSONObject().put("id", id).put("banned", banned)) { reopen(id) }

    fun removeDevice(cid: Long, id: Long) =
        req("POST", "/admin/device/remove", body = JSONObject().put("id", id)) { reopen(cid) }

    fun removeShop(cid: Long, id: Long) =
        req("POST", "/admin/shop/remove", body = JSONObject().put("id", id)) { reopen(cid) }

    // ── پلن‌ها
    fun loadPlans() = req("GET", "/admin/plans") { j ->
        plans.clear()
        val a = j.optJSONArray("plans")
        if (a != null) for (i in 0 until a.length()) plans.add(a.getJSONObject(i))
    }

    fun savePlan(b: JSONObject, done: () -> Unit) =
        req("POST", "/admin/plan/save", body = b) { msg = "ذخیره شد"; loadPlans(); done() }

    fun deletePlan(id: Long) =
        req("POST", "/admin/plan/delete", body = JSONObject().put("id", id)) { j ->
            msg = if (j.optBoolean("archived")) "پلن پرداخت دارد؛ فقط غیرفعال شد" else "حذف شد"
            loadPlans()
        }

    // ── پرداخت‌ها
    fun loadPayments(reset: Boolean) {
        val page = if (reset) 1 else payPage + 1
        req("GET", "/admin/payments", mapOf("status" to payFilter, "page" to page.toString())) { j ->
            if (reset) payments.clear()
            val a = j.optJSONArray("items")
            val n = a?.length() ?: 0
            for (i in 0 until n) payments.add(a!!.getJSONObject(i))
            payPage = page
            payMore = n >= 40
        }
    }

    // ── کد تخفیف
    fun loadCoupons() = req("GET", "/admin/coupons") { j ->
        coupons.clear()
        val a = j.optJSONArray("items")
        if (a != null) for (i in 0 until a.length()) coupons.add(a.getJSONObject(i))
    }

    fun saveCoupon(b: JSONObject, done: () -> Unit) =
        req("POST", "/admin/coupon/save", body = b) { msg = "ذخیره شد"; loadCoupons(); done() }

    fun deleteCoupon(id: Long) =
        req("POST", "/admin/coupon/delete", body = JSONObject().put("id", id)) { msg = "حذف شد"; loadCoupons() }
}
