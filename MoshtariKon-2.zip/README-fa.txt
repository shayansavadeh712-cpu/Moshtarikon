مدیریت مشتری‌کن - اپ مدیر
GitHub: همین پوشه را در یک مخزن جدید آپلود کن؛ Actions اپ را می‌سازد (artifact: MoshtariKon-APK).
